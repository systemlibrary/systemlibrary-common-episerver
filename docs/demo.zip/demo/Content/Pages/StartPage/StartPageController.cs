using EPiServer.Web.Mvc;

using Microsoft.AspNetCore.Mvc;
namespace Demo;

public class StartPageController : PageController<StartPage>
{
    public ActionResult Index(StartPage currentContent)
    {
        return View();
    }
}