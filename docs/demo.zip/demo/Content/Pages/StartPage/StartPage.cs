using System.ComponentModel.DataAnnotations;

using EPiServer.Core;
using EPiServer.DataAnnotations;

using SystemLibrary.Common.Episerver.Attributes;
using SystemLibrary.Common.Episerver.Properties;
using SystemLibrary.Common.Episerver.FontAwesome;

namespace Demo;

[ContentType(DisplayName = "Start Page", GUID = "7C3BBD03-5D83-4E75-A1E9-BCF5DF5F99B2")]
[ContentIcon(FontAwesomeSolid.house)]
public class StartPage : PageData
{
    [Display(Name = "Tip", Description = "Welcome to your brand new website")]
    public virtual Message Tip { get; set; }

    [Display(Name = "Parent", Description = "A link to the parent, where 'this' is created/living under")]
    public virtual ParentLinkReference ParentRef { get; set; }

    [Display(Name = "Expires", Description = "A date time property, but only date can be selected, time is hidden")]
    [DateSelection]
    public virtual DateTime Expires { get; set; }
}