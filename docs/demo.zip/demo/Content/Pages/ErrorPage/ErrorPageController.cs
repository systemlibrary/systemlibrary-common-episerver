using EPiServer.Web.Mvc;
using Microsoft.AspNetCore.Mvc;

namespace Demo.Content.Pages;

public class ErrorPageController : PageController<ErrorPage>
{
    public ViewResult Index(ErrorPage currentPage, string path)
    {
        return View("Index", currentPage);
    }
}