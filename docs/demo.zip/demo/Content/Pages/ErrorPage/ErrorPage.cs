using EPiServer.Core;
using EPiServer.DataAnnotations;

using SystemLibrary.Common.Episerver;
using SystemLibrary.Common.Episerver.Attributes;

namespace Demo.Content.Pages;

[ContentType(DisplayName = "Error Page", Description = "Error", GUID = "10A8191B-C9AE-433A-860B-7B7EEE758A3C", GroupName = "Single Pages")]
[ContentIcon(SystemLibrary.Common.Episerver.FontAwesome.FontAwesomeSolid.stop)]
public class ErrorPage : PageData, IErrorPage
{
    public virtual IList<int> StatusCodes { get; set; }
}