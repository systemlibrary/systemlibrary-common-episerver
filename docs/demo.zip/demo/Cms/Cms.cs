using SystemLibrary.Common.Episerver;

namespace Demo;

public class Cms : BaseCms
{
}