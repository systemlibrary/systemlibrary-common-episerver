﻿using SystemLibrary.Common.Web;

public class LogWriter : ILogWriter
{
    public void Write(string message)
    {
        Dump.Write(message);
    }
    public void Error(string message)
    {
        Dump.Write(message);
    }
    public void Warning(string message)
    {
        Dump.Write(message);
    }
    public void Debug(string message)
    {
        Dump.Write(message);
    }
    public void Information(string message)
    {
        Dump.Write(message);
    }
    public void Trace(string message)
    {
        Dump.Write(message);
    }
}