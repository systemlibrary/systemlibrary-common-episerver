using SystemLibrary.Common.Episerver;
using SystemLibrary.Common.Episerver.Extensions;

namespace Demo;

public class Program
{
    public static void Main(string[] args)
    {

        var appSettingsPath = AppContext.BaseDirectory + "appSettings.json";
        try

        {
            Cms.CreateHostBuilder<Program>(args, appSettingsPath)

            .Build()
            .Run();
        }
        catch (Exception ex)

        {
            Log.Error(ex);
        }
    }

    public void ConfigureServices(IServiceCollection services)
    {
        var options = new CmsServicesCollectionOptions();

        options.InitialLanguagesEnabled = "no";

        services.AddCommonCmsServices<CurrentUser, LogWriter>(options);
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        var options = new CmsAppBuilderOptions();

        options.UseHttpsRedirection = false;

        app.UseCommonCmsApp(env, options);
    }
}